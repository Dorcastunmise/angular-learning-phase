def log(x)
end

[].each do |x|
  log(x)
end

__END__
# Classes
class Object
  private
  def log: (bot x) -> nil
end
