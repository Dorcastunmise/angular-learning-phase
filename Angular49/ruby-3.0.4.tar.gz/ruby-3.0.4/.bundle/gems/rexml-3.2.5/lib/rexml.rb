# frozen_string_literal: true

require_relative "rexml/document"
